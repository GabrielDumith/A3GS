const formulario = document.getElementById("formulario");


formulario.addEventListener("submit", (evento)=>{
    evento.preventDefault();

    alert("tudo certo!");
});