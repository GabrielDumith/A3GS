import React from 'react'

import Routes from './Routes'


const Root = () =>{return (  <Routes />)}


export default Root