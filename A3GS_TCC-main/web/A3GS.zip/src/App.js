import React from 'react';

// import Home from './pages/Home';
import About from './pages/About';

import "./style/index.css"



const App = () => (
    <>
    <button> <About /> </button>
    </>

)
    
    



export default App