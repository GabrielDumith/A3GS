import React from 'react'

const Contact = () => <h1>Contact</h1>

export default Contact