import React from 'react'

const About = () => <h1>About </h1>

export default About